2026 年华数杯 C 题支撑材料

版本：Q1/Q2 已修复版本
版本链：model v47 / code v20 / solve v17 / paper v25 / review v19
状态：Q3/Q4 正在修复，本包不是最终比赛提交版本。

一、环境
建议使用 Python 3.11 或更高版本。
安装依赖：
    python -m pip install -r requirements.txt

二、输入目录
程序默认从当前目录下的“附件数据”文件夹读取官方原始数据：
    附件数据/GPU_information.xlsx
    附件数据/network_latency.xlsx
    附件数据/power_mapping.xlsx
    附件数据/region_time_data.xlsx
    附件数据/storage_information.xlsx
    附件数据/workload_trace.xlsx

官方原始赛题数据不重复打包进本支撑材料。运行时请将官方“附件数据”文件夹放在 solution.py 同级目录。

三、运行
PowerShell：
    Remove-Item Env:MMW_MAX_RUNTIME_SECONDS -ErrorAction SilentlyContinue
    $env:PYTHONIOENCODING='utf-8'
    python .\solution.py

程序默认不设置墙钟截止，并在当前目录的 output 文件夹生成结果。完整运行耗时较长。
